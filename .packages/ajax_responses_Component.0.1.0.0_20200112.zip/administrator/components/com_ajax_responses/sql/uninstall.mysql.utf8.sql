DROP TABLE IF EXISTS `#__ajax_responses_details`;

